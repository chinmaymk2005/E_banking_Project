window.onload(()=>
{
    localStorage.clear();
})